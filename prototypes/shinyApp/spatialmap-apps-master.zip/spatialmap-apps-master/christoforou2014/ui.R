shinyUI(
    fluidPage(
        p("Please use",
          a("https://lgatto.shinyapps.io/christoforou2015",
            href = "https://lgatto.shinyapps.io/christoforou2015"))))
