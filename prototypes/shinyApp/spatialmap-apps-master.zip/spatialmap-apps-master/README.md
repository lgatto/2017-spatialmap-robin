Online pRolocGUI shinyapps for
[spatialmap.org](http://spatialmap.org). The data and the interactive
interface are available in the
[`pRolocdata`](http://bioconductor.org/packages/release/data/experiment/html/pRolocdata.html)
[`pRolocGUI`](http://bioconductor.org/packages/release/bioc/html/pRolocGUI.html)
packages.
